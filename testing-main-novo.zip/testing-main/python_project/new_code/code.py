#importing all the dependencies packages
import json
import functions
import csv
import nltk
from nltk.corpus   import stopwords
from nltk.tokenize import word_tokenize
from nltk.tokenize import RegexpTokenizer
from nltk.stem     import PorterStemmer
from nltk.stem     import WordNetLemmatizer
from nltk.stem.lancaster import LancasterStemmer
import string
import re
import csv
import pandas as pd
import numpy as np
import spacy
import sys
import en_core_web_sm
from textblob import Word
from sklearn.feature_extraction.text import CountVectorizer
nlp = spacy.load("en_core_web_sm")
REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
STOPWORDS = set(stopwords.words('english'))
f = open('data.json')
json_data = json.load(f)  
def extract_documents(sentence1,productName):
    #removing punctuations and stopwords to extract main relavant data
    document_list = []
    sentence1 = sentence1.lower() # lowercase text
    sentence1 = REPLACE_BY_SPACE_RE.sub(' ', sentence1) # replace REPLACE_BY_SPACE_RE symbols by space in text. substitute the matched string in REPLACE_BY_SPACE_RE with space.
    sentence1 = BAD_SYMBOLS_RE.sub('', sentence1) # remove symbols which are in BAD_SYMBOLS_RE from text. substitute the matched string in BAD_SYMBOLS_RE with nothing. 
    sentence1 = sentence1.replace('x', '')
    sentence1 = functions.remove_stopwords_spacy(sentence1)
    stem_words_text = functions.replace_words_with_dict(sentence1,json_data) # looping through json for synonyms and abbreviations
    lemma_sentence = functions.lemmatize_text_spacy(stem_words_text) #apply lemmatization for sentence
    stem_text = functions.stem_text_spacy(lemma_sentence) #apply stemming for sentence
    print(stem_text)
    #comparisions based on products
    df = pd.read_excel (r'./test_sample_1.xlsx')
    data = df[['Keywords (m)','Product','Document Name','DOC ID']]
    data = data.sort_values(by=['Product'])
    data = data.dropna()
    data = data.replace(r'^\s*$', np.nan, regex=True)
    data['Product'] = data['Product'].apply(str.lower)
    data['extracted_sentence'] = str(stem_text)
    data['Keywords (m)'] = data['Keywords (m)'].str.lower()
    data = data[data.Product.str.contains('none|n/a|no data|nan')==False]
    data = data[data.Product.str.contains(str(productName).lower())]
    data['new_keywords'] = ''
    data['score']=0.0
    #importing the keywords excel for comparision
    for sent in data['Keywords (m)']:
        t = re.sub(r'\s*,\s*',',',str(sent))
        data['Keywords (m)'] = data['Keywords (m)'].replace([sent],t)
    for idx1,sentence2 in data['Keywords (m)'].iteritems():
        string_words_new = ''
        extracted_words_from_key_words = set()
        if str(sentence2).lower() not in ('nan','n/a','none','no data'):
            sentence2 = functions.remove_stopwords_spacy(sentence2) # remove stopwords from text
            stem_words_text = functions.replace_words_with_dict(sentence2,json_data) # looping through json for synonyms and abbreviations
            lemma_words = functions.lemmatize_text_spacy(stem_words_text) #apply lemmatize 
            stem_text2 = functions.stem_text_spacy(lemma_words) # apply stemming
            data.at[idx1, 'new_keywords'] = stem_text2
    for idx,sentence in data['new_keywords'].iteritems():
        if str(sentence).lower() not in ('nan','n/a','none','no data','','[none]'):
            array_toCompare_initial = np.array(sentence.split(','))
            array_toCompare_final = [elem.strip().lower() for elem in array_toCompare_initial]
            flt_sent2 = [w for w in array_toCompare_final if not w.lower() in STOPWORDS and w not in string.punctuation and w not in ('nan','n/a','none','no data','','[none]')]
            flt_sent2_final = list(set(flt_sent2))
            display(flt_sent2_final)
            matching_word_count = functions.count_matching_words(stem_text, flt_sent2_final)
            common_elements = matching_word_count
            #Calculating the score
            score = common_elements/len(flt_sent2_final)*100
            data.at[idx, 'score'] = score
    data.to_csv('pavan.csv')
    df_final = data.nlargest(3, 'score')
    result_final_output = df_final.to_json(orient="records")
    return result_final_output

if __name__ == "__main__":
    extract_documents(sys.argv[1],sys.argv[2])