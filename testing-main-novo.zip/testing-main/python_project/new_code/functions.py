def remove_stopwords_spacy(text):
    doc = nlp(text)
    filtered_tokens = [token.text for token in doc if not token.is_stop]
    filtered_text = ' '.join(filtered_tokens)
    return filtered_text
#spacy lemmatize
def lemmatize_text_spacy(text):
    doc = nlp(text)
    lemmatized_words = [token.lemma_ for token in doc]
    return lemmatized_words
#spacy Stemming
def stem_text_spacy(text):
    stemmed_words = [Word(word).stem() for word in text]
    stemmed_text = " ".join(stemmed_words)
    return stemmed_text

def count_matching_words(sentence, words):
    sentence_words = sentence.lower()
    matching_words = [word for word in words if word.lower() in sentence_words]
    return len(matching_words)

def replace_words_with_dict(sentence,json_data):
    modified_sentence = sentence.lower()
    for key, word_array in end_json.items():
        for word in word_array:
            modified_sentence = modified_sentence.replace(word, key)  # Replace word with its corresponding value
    return modified_sentence