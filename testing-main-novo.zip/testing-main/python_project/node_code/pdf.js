const data= require('./pavan.json');

fileds= data.analyzeResult.documents[0].fields.Data1.valueArray

// length of the array
// initialize a empty dictionary with Inssue On, SIV No. Item Code as keys
var array = []
// iterate through the array

const columns=['Dept Code.', 'Dept.', 'Issued on','SIV No.','Item Code','Item Description','Qty/Unit','Unit','Issued Qty','Unit Price','Total Price']

const myPromise = new Promise((resolve, reject) => {
    for (var i=0; i<fileds.length; i++) {
        let dict = {}
        let line_considered = fileds[i]['valueObject']
        // get the keys of the dictionary
        //console.log('inside')
        // iterate through columns
        for (var j in columns) {
            //console.log(columns[j])
            //check for the column match
            if (columns[j] in line_considered) {
                dict[columns[j]] = line_considered[columns[j]].content
                console.log(line_considered[columns[j]].content)
                //console.log(columns[j] + " -> " + line_considered[columns[j]].content);
            }
            else{
                dict[columns[j]]= ''
                //console.log(" "+columns[j])
            }
        }
        array.push(dict)
    }
    resolve();
});
async function run()  {
    myPromise.then( () => console.log(array)
    )
}run()