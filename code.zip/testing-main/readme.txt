
command to execute the function from commandline - 
python extract_document.py "place your query here"
for example run the bellow code
python extract_document.py "Can you lower the dose of metformin when you start a patient on Rybelsus?  Is there any data around this question that can be provided?