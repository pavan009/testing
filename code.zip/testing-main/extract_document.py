#importing all the dependencies packages
import json
import csv
import nltk
from nltk.corpus   import stopwords
from nltk.tokenize import word_tokenize
from nltk.tokenize import RegexpTokenizer
from nltk.stem     import PorterStemmer
from nltk.stem     import WordNetLemmatizer
import string
import re
import csv
import pandas as pd
import numpy as np
import sys
def extract_documents(sentence1):
    #importing given keywords file associated with 
    df1 = pd.read_excel (r'./test_data_document.xlsx')
    #importing the keywords excel for comparision
    for sent in df1['Keywords (m)']:
        t = re.sub(r'\s*,\s*',',',str(sent))
        df1['Keywords (m)'] = df1['Keywords (m)'].replace([sent],t)
    #removing punctuations and stopwords to extract main relavant data
    document_list = []
    stop_words = stopwords.words('english')
    word_tokens = word_tokenize(sentence1)
    filtered_sentence = [w for w in word_tokens if not w.lower() in stop_words and w not in string.punctuation]
    fs = [x.lower() for x in filtered_sentence]
    for idx,sentence in df1['Keywords (m)'].iteritems():
        if str(sentence).lower() not in ('nan','n/a','none'):
            array_toCompare = np.array(sentence.split(','))
            flt_sent2 = [w for w in array_toCompare if not w.lower() in stop_words and w not in string.punctuation]
    #         commented stemming and lemmatization as it was predicting incorrect
    #         for w in flt_sent2:
    #             stem_word = porter.stem(w)
    #             lemma_word = lt.lemmatize(w)
    #             filtered_sentence2.append(lemma_word)
            ac = [x.lower() for x in flt_sent2]
            common_elements = list(set(fs).intersection(set(ac)))
            union_element = list(set(fs).union(set(ac)))
            #Calculating the score
            score = len(common_elements)/len(fs)*100
            df1.at[idx, 'score'] = score
    max_value = max(np.array(df1['score']))
    list_max_score = df1.index[df1['score'] == max_value].tolist()
    if(max_value != 0.0):
        for i in list_max_score:
            document_list.append(df1['Document Name'][i])
    else:
        document_list.append('no proper match found')
    print(document_list)
    return document_list

if __name__ == "__main__":
    extract_documents(sys.argv[1])